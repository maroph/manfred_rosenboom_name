Ihre beste Seite - 
Eleganter Einseiter als pers�nliche Homepage
--------------------------------------------
c't 18/13, Seite 174 (dbe)

index.htm	Beispiel-Webseite
styles.css	CSS-Stylesheet f�r die Webseite
yanone.css	CSS-Stylesheet f�r den Webfont

yanone.woff	Webfont "Yanone Kaffeesatz"

foto.jpg	Hintergrundfoto
twitter.png	Icons f�r Links zu Twitter, Facebook etc.
facebook.png
youtube.png
rss.png